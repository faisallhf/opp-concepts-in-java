# Encapsulation.
Encapsulation
