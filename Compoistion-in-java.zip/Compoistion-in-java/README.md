# Compoistion in java
 complete code of composition in java.
